const TopBar = () => {
    return (
      <div className="topbar">
        <h1>Educational Courses</h1>
      </div>
    );
  };
  
  export default TopBar;